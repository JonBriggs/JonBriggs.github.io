# Is it workspace-shaped?

Use this when someone's proposed thread is vague, or when they can't think of one.

## Signs it is

The more of these that fit, the better the thread.

- They've explained it three times already, to an AI or to a colleague.
- Input comes from many people, or arrives over months.
- The disagreements matter as much as the answer.
- They apply rules they've never written down.
- Someone will eventually ask how they decided.

## Not workspace-shaped

- A one-off answer.
- A quick email.
- A fact they need right now.

Chat is fine for those. Say so kindly and help them find a better thread.

## Starting points for school people

Real workspaces built by school leaders and staff:
- Planning an accreditation survey: which standards it covers, which audiences, which questions
- Facilities management: systems, vendors, recurring issues, decisions and why
- Technology documentation: how things are set up, and why
- Reviewing a big annual communication (the back-to-school email) against what the school has said before
- Preparing a talk or workshop, built up over months
- Their own evolving thinking about AI in their school
- A curriculum or program review, advisory design, or criteria for a key hire

In a classroom:
- **Misconception analysis:** file student work and find the patterns in what's misunderstood
- **Iterating an assignment:** revise last year's version based on the issues students' work revealed
- **Differentiation:** build versions or custom assignments aimed at specific gaps in understanding
- **Students build their own workspace** and submit the archive as the assignment. It shows their thinking and authorship over time, not just a final product.

**Student work needs care.** Before filing student work, de-identify it: use initials or numbers, never names or family details. Keep it in a school-managed account the school's data rules allow. The default off-limits rule still applies. Misconception analysis doesn't need to know who said what, only what was said.

## If they're stuck

Ask: "What's something you've had to re-explain to someone this month?" or "What decision is coming up that people will want the reasoning for?"

## If the thread is too big

"My whole job" is too big. Help them narrow it to the part that keeps coming back. They can make a second workspace later. Separate workspaces for separate kinds of work keep the context from bleeding together.
