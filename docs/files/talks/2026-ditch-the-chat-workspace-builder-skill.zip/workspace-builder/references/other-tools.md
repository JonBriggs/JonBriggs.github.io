# When you can't create files directly

The method doesn't depend on the tool. What changes is who saves the files.

## Claude.ai Project (recommended; works on the free plan)

1. Have them create a Project named after their thread.
2. Write the **Project instructions** for them to paste. Include:
   - the HOW-IT-WORKS content;
   - this line: "Use the five routines in HOW-IT-WORKS. Answer from the Project knowledge and cite file names."
3. Produce **HOW-IT-WORKS.md** and **INDEX.md** as files they download and add to the Project's knowledge.
4. **"File this" in a Project:** you can't save files into the Project yourself.
   - Produce the artifact file and a single `notes-YYYY-MM-DD.md` file that holds all the derived notes from that artifact, each with its own heading and frontmatter block.
   - Ask them to download both and add them to the Project knowledge.
   - Remind them that it's two downloads and one drag. That's the whole filing step.
5. **INDEX.md:** produce an updated version when it changes and ask them to replace the old one.
6. **Tell them the limits.** Project knowledge has size limits, and files they don't add won't persist. If the workspace grows large, suggest moving it to a folder with Claude Cowork or another tool that can work with files directly.

## Microsoft Copilot Notebooks · Google Gemini Gems · NotebookLM · ChatGPT Projects

These tools can read a set of files but usually can't write them.

1. Same setup:
   - HOW-IT-WORKS goes into the tool's instructions or custom-instructions field, if it has one. Also add it as a source file.
   - Artifacts and notes go in as uploaded sources.
2. "File this" works as above: you produce the files, and they add them as sources.
3. NotebookLM has no instructions field. Put HOW-IT-WORKS in as the first source, and start each session by asking it to read that file.
4. Data rule: if their school licenses one of these tools, school material belongs in the school-managed account, not a personal one.

## A plain folder

If they'd rather keep files on their own computer:

1. Have them make a folder with the default structure.
2. Produce each file's contents for them to save.
3. Any AI tool they later connect to that folder can use the same routines, because the rules live in HOW-IT-WORKS, not in the tool.
