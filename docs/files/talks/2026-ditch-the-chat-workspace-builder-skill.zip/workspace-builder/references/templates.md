# Templates

Fill these from the interview. Replace bracketed text. Keep their wording wherever possible. A HOW-IT-WORKS in their own voice is worth more than a polished one in yours.

---

## HOW-IT-WORKS.md

```markdown
# How this workspace works

_Owner: [name] · Started: [date] · Last reviewed: [date]_

## What this is for
[The thread, in one or two sentences, in their words.]

## Context you should never have to ask me for
- Who I am: [role, school or organization]
- Who this is for: [audiences — e.g., faculty, board, parents, students]
- Constraints: [time, policy, politics, what's already decided]
- How I like to work: [e.g., short drafts first; push back on me; school register, not corporate]

## What counts (the filing-cabinet answer)
On each card I'd keep: [their answer].
Note types in this workspace:
- OBS — [their word for it]: something noticed
- CLAIM — [their word]: a position someone holds or is testing (holder's name first if it isn't mine)
- Q — [their word]: an open question worth keeping open
- DEC — [their word]: something decided, who decided, when
- REF — [their word]: a source and the takeaway that matters to me

## What to keep, and what to ignore
- Keep: [e.g., anything a colleague said that changed my mind; data with its date]
- Ignore: [e.g., logistics, scheduling back-and-forth, pleasantries]

## Never compress
- Disagreements stay disagreements. Record each view in its owner's words and link them. Never average.
- Exact wording for anything someone will be held to.
- Who said what, and when.
- [their additions]

## Off-limits
- No names or identifying details of students or families, in any account. (Exceptions only if I say so explicitly and school data rules allow it.)
- [confidential material, people, topics]

## The month question
After a month, the first thing I'll ask is: "[their question]"

## Routines
- "File this" — save the artifact first, then derive notes, then update the index.
- "What do I think about ___?" — answer only from this workspace, with citations.
- "Where have I changed my mind?" — read retired and contested notes.
- "Review what you know about me" — monthly; retire what's stale.
- "Go wide" — set the workspace aside on purpose, and say so.

## My rules (grows over time)
_Each correction usually reveals a rule. Add it here with the date._
- [date] — [rule]
```

---

## Artifact file — `artifacts/YYYY-MM-DD-short-name.md`

```markdown
---
type: artifact
title: [what this is]
date: YYYY-MM-DD          # when it happened; filed date below
filed: YYYY-MM-DD
kind: conversation | document | email | meeting notes | survey | other
source: [where it came from — "conversation with Claude", "uploaded PDF", "pasted email from ___"]
---

[The full text, intact. For a conversation, save what the person said in their own words. Summarize your own turns briefly; never summarize theirs.]
```

---

## Note file — `notes/TYPE-NNNN-short-slug.md`

```markdown
---
id: CLAIM-0007
type: claim
title: [one line, stated as the idea itself]
status: active            # active | contested | retired
created: YYYY-MM-DD
derived_from: artifacts/YYYY-MM-DD-short-name.md
quote: "[the exact words this came from, when there are any]"
related: []               # other note IDs that connect
conflicts: []             # note IDs that disagree with this one (list it on both notes)
---

[Two to five sentences: the idea, why it matters, and anything you inferred rather than read. Label inferences: "Interpretation: ..."]

## History
- YYYY-MM-DD — created from [artifact]
```

Numbering: count up per type (OBS-0001, OBS-0002 …). IDs never change. Titles can.
Retiring: set `status: retired` and add a History line with the date and the reason.

---

## INDEX.md

```markdown
# Index

_Updated: [date] · [n] artifacts · [n] notes_

## Recently filed
- [date] — [artifact title] → [note IDs]

## By type
### Claims
- CLAIM-0001 — [title] (active)
...

## Open conflicts
- CLAIM-0003 ↔ CLAIM-0007 — [one-line description, both positions, no verdict]

## Needs review
- [anything flagged, any note you weren't sure about]
```
