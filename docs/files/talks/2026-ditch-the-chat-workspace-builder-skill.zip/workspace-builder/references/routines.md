# The five routines

These are the phrases the person will use from now on. Each one should work the same way every time.

## "File this"

1. **Save the artifact first.** Write the conversation or document to `artifacts/YYYY-MM-DD-short-name.md` using the artifact template. Use the date the thing happened (the meeting, the email); if that's unknown, use today.
   - For a conversation, keep the person's words intact. Summarize your own turns briefly.
   - If a file with that name exists, add `-2`.
2. **Check for off-limits material** against HOW-IT-WORKS before writing anything. To redact:
   - Replace each item with `[student, details withheld]` (or `[family, …]`, `[confidential, …]`).
   - Add one line at the top of the artifact: "Redacted on YYYY-MM-DD: [what kind of thing, not the content]."
   - Never quote redacted text in a note.
   - Tell the person what you removed. Remind them the original still exists wherever it came from, and is not in the workspace.
3. **Derive notes.** Read the artifact against "What counts" and "What to keep." Create one note per distinct idea, usually 3–10 per artifact. Don't pad. Each note gets:
   - `derived_from`, pointing at the artifact;
   - a short exact `quote` when the person said it directly;
   - an "Interpretation:" label on anything you inferred.
4. **Link.** Check existing notes.
   - Same idea from a new source: add the new artifact to the existing note's History. Don't create a duplicate.
   - Opposing idea: create the note, then list each note's ID in the other's `conflicts:` field. Don't resolve it.
   - Something that changes an existing note: propose marking the old one `contested` or `retired`. Ask first.
5. **Update INDEX.md.**
6. **Report back briefly.**
   - What you filed.
   - The notes you created, with titles.
   - Any conflicts you found.
   - One or two notes you're least sure about. Ask them to check those.

## "What do I think about ___?"

1. Search notes first, then the artifacts behind them.
2. Answer only from the workspace. Cite note IDs and artifacts, e.g. "(CLAIM-0004, from artifacts/2026-09-12-board-retreat.md)".
3. Separate what they've said from what you're inferring.
4. If the workspace doesn't cover it, say so plainly. Offer to answer from general knowledge, clearly labeled as outside the workspace.
5. If notes disagree, show both sides. Don't pick one.

## "Where have I changed my mind?"

1. List retired and contested notes, newest first.
2. For each, give:
   - what they used to think;
   - what replaced it, if anything;
   - the reason in the History line;
   - the artifact that marked the change.
3. Group by theme if there are many.

## "Review what you know about me"

Suggest this monthly, and whenever their role, school or plans change.

1. Read HOW-IT-WORKS aloud in short sections. For each one, ask: "Still true?"
2. List the active notes that are most load-bearing: the most linked, or the most often cited.
3. Ask what's stale.
4. Act on the answers:
   - Retire stale notes with a reason. Never delete.
   - Update HOW-IT-WORKS.
   - Set "Last reviewed" to today's date.
5. Remind them gently why this matters. Workspaces remember well and forget badly. An old plan or a changed stance keeps shaping answers until it's retired.

## "Go wide"

Use this for brainstorming, stress-testing a plan, or seeing a problem fresh.

1. Say explicitly that you're setting the workspace aside.
2. Answer from general knowledge and fresh thinking. Don't anchor on their past positions.
3. At the end, offer to file anything worth keeping, as a new artifact. Note in the artifact that it came from a "go wide" session.

## Corrections, any time

When they correct an output:

1. Fix it.
2. Ask: "What rule did that fix reveal?"
3. If they name one, add it to "My rules" in HOW-IT-WORKS with the date.
4. If the mistake came from a note, fix the note too, and add a History line.
